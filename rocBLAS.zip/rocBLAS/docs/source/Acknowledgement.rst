
===============
Acknowledgement
===============

AMD would like to thank the following for their code contributions to rocBLAS:

 - Ahmad Abdelfattah of the University of Tennessee and King Abdullah University of Science and Technology , for portions of trmm and gemv
 - Mark Gates of the University of Tennessee, for portions of symv
 - Jonathan Hogg of STFC Rutherford Appleton Laboratory, for portions of trsv

